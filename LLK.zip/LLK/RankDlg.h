#pragma once
#include "afxcmn.h"


// CRankDlg �Ի���

class CRankDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CRankDlg)

public:
	CRankDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CRankDlg();

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_RANK };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedRadioEasy();
	afx_msg void OnBnClickedRadioGame();
	CListCtrl m_listRank;
//	afx_msg void OnPaint();
	virtual BOOL OnInitDialog();
	void DisplayRank();
	int m_nMode;
};
