#include "stdafx.h"
#include "Graph.h"

Graph::Graph()
{
}


Graph::~Graph()
{
}

void Graph::InitGraph()//��ʼ��ͼ�ṹ
{
	m_nVexnum = 0;
	m_nArcnum = 0;
	for (int i = 0; i < MAX_VERTEX_NUM; i++)
	{
		m_Vertices[i] = -1;
		for (int j = 0; j < MAX_VERTEX_NUM; j++)
			m_AdjMatrix[i][j] = false;
	}
}
// ���Ӷ���
int Graph::AddVertex(int nInfo)
{
	if (m_nVexnum >= MAX_VERTEX_NUM)
		return m_nVexnum;
	m_Vertices[m_nVexnum] = nInfo;
	m_nVexnum++;
	return m_nVexnum;
}


// ���ӱ�
void Graph::AddArc(int nIndex1, int nIndex2)
{
	m_AdjMatrix[nIndex1][nIndex2] = true;
	m_AdjMatrix[nIndex2][nIndex1] = true;
}


int Graph::GetVertex(int nIndex)
{
	return m_Vertices[nIndex];
}


void Graph::ClearGraph()
{
	InitGraph();
}

int Graph::GetVexNum()
{
	return m_nVexnum;
}

void Graph::setVertex(int nIndex,int number)
{
	m_Vertices[nIndex] = number;
}

void Graph::UpdateVertex(int nIndex, int nInfo)
{
	m_Vertices[nIndex] = nInfo;
}

// ��ѯ��������֮���Ƿ��б�
bool Graph::GetArc(int nIndex1, int nIndex2)
{
	if (m_AdjMatrix[nIndex1][nIndex2] == m_AdjMatrix[nIndex2][nIndex1] && m_AdjMatrix[nIndex1][nIndex2] == 1)
		return true;
	return false;
}
