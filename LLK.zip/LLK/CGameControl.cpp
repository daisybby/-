#include "stdafx.h"
#include "CGameControl.h"
#include "CGameLogic.h"
#include "global.h"
#include "Graph.h"
CGameControl::CGameControl()
{
	m_nGrade = 0;
}


CGameControl::~CGameControl()
{
}


int CGameControl::GetElement(int nRow, int nCol)
{
	return m_Graph.GetVertex(nRow*16+nCol);
}


void CGameControl::SetFirstPoint(int nRow, int nCol)
{
	m_ptSelFirst.row = nRow;
	m_ptSelFirst.col = nCol;
	m_ptSelFirst.info = m_Graph.GetVertex(nRow*CGameControl::s_nCols+nCol);
}


void CGameControl::SetSecPoint(int nRow, int nCol)
{
	m_ptSelSec.row = nRow;
	m_ptSelSec.col = nCol;
	m_ptSelSec.info= m_Graph.GetVertex(nRow*CGameControl::s_nCols + nCol);
}


bool CGameControl::Link(Vertex aPath[160],int& nVexNum)
{
	if (m_ptSelFirst.row == m_ptSelSec.row&&m_ptSelFirst.col == m_ptSelSec.col)//ѡ�е�ͬһ��ͼƬ
	{
		return false;
	}
	if (m_Graph.GetVertex(m_ptSelFirst.row*CGameControl::s_nCols+m_ptSelFirst.col) != m_Graph.GetVertex(m_ptSelSec.row*CGameControl::s_nCols+m_ptSelSec.col))
		return false;
	CGameLogic logic;
	if (logic.IsLink(m_Graph, m_ptSelFirst, m_ptSelSec) == true)
	{
		logic.Clear(m_Graph,m_ptSelFirst,m_ptSelSec,m_Graph);
		nVexNum=logic.GetVexPath(m_Graph,aPath);
		return true;
	}
	return false;
}


 int CGameControl::IsWin(int nTime)//�ж�ʤ��
{
	CGameLogic logic;

	if (nTime <=0)
	{
		m_Graph.ClearGraph();
		return GAME_LOSE;
	}
	if (logic.IsBlank(m_Graph)==true)
	{
		m_Graph.ClearGraph();
		return GAME_SUCCESS;
	}
	return GAME_PLAY;
}

bool CGameControl::Help(Vertex anPath[160], int& nVertexNum)
{
	CGameLogic logic;
	if (logic.IsBlank(m_Graph) == true)
	{
		nVertexNum = 0;
		return false;
	}
	if (logic.SearchValidPath( m_Graph))
	{
		m_nGrade -= 20;
		nVertexNum = logic.GetVexPath(m_Graph,anPath);
		return true;
	}
	return false;
}


// ����
void CGameControl::Reset()
{
	CGameLogic logic;
	logic.ResetGraph(m_Graph);
}

void CGameControl::SetFlag(FLAG f)
{
	flag = f;
}

FLAG CGameControl::GetFlag()
{
	return flag;
}

// ��ȡ����
int CGameControl::GetGrade()
{
	return m_nGrade;
}

int CGameControl::GetLevel()
{
	return number;
}

void CGameControl::setGrade(int nGrade)
{
	m_nGrade += nGrade;
}

void CGameControl::InitGrade()
{
	m_nGrade = 0;
}

// ʹ�õ�������
bool CGameControl::ProLink()
{
	return true;
}


// �������
bool CGameControl::SaveScore()
{
	return false;
}
