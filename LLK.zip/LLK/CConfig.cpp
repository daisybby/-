#include "stdafx.h"
#include "CConfig.h"
#include <locale> 

CConfig* CConfig::m_pConfig = NULL;
CConfig::CConfig()
{
	
}


CConfig::~CConfig()
{
}

void CConfig::setStyle(int style)
{
	m_nStyle = style;
}

int CConfig::getStyle()
{
	return m_nStyle;
}

void CConfig::setElemPath(CString path)
{
	strElemPath = path;
}

CString CConfig::getElemPath()
{
	return strElemPath;
}

void CConfig::setMaskPath(CString path)
{
	strMaskPath = path;
}

CString CConfig::getMaskPath()
{
	return strMaskPath;
}

CConfig* CConfig::GetSingleInstance()
{
	if (m_pConfig == NULL)
	{
		m_pConfig = new CConfig;
		m_pConfig->Load();
	}
	return m_pConfig;
}

void CConfig::ReleaseInstance()
{
	if (m_pConfig != NULL)
	{
		delete m_pConfig;
		m_pConfig = NULL;
	}
}

void CConfig::save()
{
	CStdioFile file;
	CString path = _T("theme\\config.ini");
	file.Open(path, CFile::modeCreate | CFile::modeWrite);
	setlocale(LC_CTYPE, ("chs"));
	file.SeekToBegin();
	CString style;
	style.Format(_T("%d"), m_nStyle);
	file.WriteString(style);
	file.WriteString(_T("\n"));
	file.WriteString(getElemPath());
	file.WriteString(_T("\n"));
	file.WriteString(getMaskPath());
	file.Close();
}


void CConfig::Load()//��ȡ������Ϣ
{
	CStdioFile file;

	CString path = _T("theme\\config.ini");
	setlocale(LC_CTYPE, ("chs"));
	file.Open(path,CFile::modeRead);
	CString style;
	file.ReadString(style);
	m_pConfig->setStyle(_ttoi(style));
	CString elemPath, maskPath;
	file.ReadString(elemPath);
	file.ReadString(maskPath);
	setElemPath(elemPath);
	setMaskPath(maskPath);
}
