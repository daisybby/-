#include "stdafx.h"
#include "CScoreDao.h"
#include "global.h"

CScoreDao::CScoreDao()
{
}


CScoreDao::~CScoreDao()
{
}


bool CScoreDao::Save(const CString& strPath, Score& score)
{
	CStdioFile file;
	file.Open(strPath, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite);
	CString mode, ascore,level;
	mode.Format(_T("0%d"), score.nMode);
	ascore.Format(_T("%d"), score.nGrade);
	level.Format(_T("%d"), score.nLevel);
	CString scores;
	switch (ascore.GetLength())
	{
	case 1:
		scores=_T("0000")+ascore;
		break;
	case 2:
		scores = _T("000") + ascore;
		break;
	case 3:
		scores = _T("00") + ascore;
		break;
	case 4:
		scores = _T("0") + ascore;
		break;
	default:
		break;
	}
	CString save;
	save = mode + score.strName + scores + level+_T("\r\n");
	file.SeekToEnd();
	file.WriteString(save);//���ļ�ĩβд��
	file.Close();
	return false;
}


// ��ȡ���а���Ϣ
int CScoreDao::Read(const CString& strPath, RankArray& ranks, int nMode)
{
	CStdioFile file;
	file.Open(strPath, CFile::modeRead);//ֻ�����ļ�
	file.SeekToBegin();
	CString score;
	Score oneScore;
	int i = 0, min=10000 ,nIndex,ascore;
	while (file.ReadString(score))
	{
		nIndex = i;
		min = 10000;
		if (i >=10)//������������С�ķ���
		{
			for (int j = 0; j < 10; j++)
			{
				if (ranks[j].nGrade < min)
				{
					min = ranks[j].nGrade;
					nIndex = j;
				}
			}
		}
		ascore = _ttoi(score.Mid(16,5));//��ȡ����
		if (_ttoi(score.Mid(0, 2)) == nMode&&i<10)
		{
			oneScore.strName = score.Mid(2, 14);
			oneScore.nLevel = _ttoi(score.Mid(21));
			oneScore.nMode = _ttoi(score.Mid(0, 2));
			oneScore.nGrade = ascore;
			ranks[nIndex] = oneScore;
			i++;
		}
		else if (i>=10&&ascore > min&&_ttoi(score.Mid(0, 2))==nMode)//��������������С��Ԫ�أ�����ģʽ��ȷ,�򱣴�
		{
			oneScore.strName = score.Mid(2, 14);
			oneScore.nLevel = _ttoi(score.Mid(21));
			oneScore.nMode = _ttoi(score.Mid(0, 2));
			oneScore.nGrade = ascore;
			ranks[nIndex] = oneScore;
			i++;
		}
	}
	file.Close();
	if (i > 10)
		return 10;
	else
		return i;
}
