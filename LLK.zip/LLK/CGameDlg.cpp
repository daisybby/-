// CGameDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "LLK.h"
#include "CGameDlg.h"
#include "afxdialogex.h"
#include "global.h"
#include "HelpDlg.h"
#include "resource.h"
#include "CScoreLogic.h"
#include "CConfig.h"
// CGameDlg �Ի���

IMPLEMENT_DYNAMIC(CGameDlg, CDialogEx)

CGameDlg::CGameDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_GAME_DIALOG, pParent)
{
	m_ptGameTop.x = 50;
	m_ptGameTop.y = 50;
	m_sizeElem.cx = 80;
	m_sizeElem.cy = 80;
	//��ʼ����Ϸ��������
	m_rtGameRect.top = m_ptGameTop.y;
	m_rtGameRect.left = m_ptGameTop.x;
	m_rtGameRect.right = m_rtGameRect.left + m_sizeElem.cx * 16;
	m_rtGameRect.bottom = m_rtGameRect.top + m_sizeElem.cy * 10;

	m_bFirstPoint = true;
	m_bPlaying = false;
	m_bPro = false;
	m_ProNum = 0;
}

CGameDlg::~CGameDlg()
{
}

void CGameDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BTN_START, m_bt_start);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_bt_stop);
	DDX_Control(pDX, IDC_BUTTON_RESET, m_bt_reset);
	DDX_Control(pDX, IDC_BUTTON_HELP, m_bt_help);
	DDX_Control(pDX, IDC_BUTTON_HINT, m_bt_hint);
	DDX_Control(pDX, IDC_GAME_TIME, m_GameProgress);
	DDX_Control(pDX, IDC_BUTTON_PRO, m_bt_pro);
}

void CGameDlg::InitElement()
{
	//��õ�ǰ�Ի������Ƶ�ڴ�
	CClientDC dc(this);
	//����bmpͼƬ��Դ
	CConfig* config=CConfig::GetSingleInstance();
	CString ElemPath = config->getElemPath();
	CString MaskPath = config->getMaskPath();
	HANDLE hBmp = ::LoadImageW(NULL, ElemPath, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

	//��������Ƶ�ڴ���ݵ��ڴ�DC
	m_dcElement.CreateCompatibleDC(&dc);
	m_dcElement.SelectObject(hBmp);

	//��������bmpͼƬ��Դ
	HANDLE hMask = ::LoadImageW(NULL,MaskPath, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

	m_dcMask.CreateCompatibleDC(&dc);
	m_dcMask.SelectObject(hMask);

	config->ReleaseInstance();
	HANDLE bmpcache = ::LoadImage(NULL, _T("theme\\Picture\\nuan_cache.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

	m_dcCache.CreateCompatibleDC(&dc);
	m_dcCache.SelectObject(bmpcache);
}

BEGIN_MESSAGE_MAP(CGameDlg, CDialogEx)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BTN_START, &CGameDlg::OnClickedBtnStart)
	ON_WM_LBUTTONUP()
	ON_BN_CLICKED(IDC_BUTTON_HINT, &CGameDlg::OnClickedButtonHint)
	ON_BN_CLICKED(IDC_BUTTON_RESET, &CGameDlg::OnClickedButtonReset)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_STOP, &CGameDlg::OnBnClickedButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_HELP, &CGameDlg::OnBnClickedButtonHelp)
	ON_BN_CLICKED(IDC_BUTTON_PRO, &CGameDlg::OnBnClickedButtonPro)
	ON_WM_SIZE()
END_MESSAGE_MAP()


// CGameDlg ��Ϣ��������


void CGameDlg::InitBackground()
{
	CClientDC dc(this);

	HANDLE bmp = ::LoadImage(NULL, _T("theme\\Picture\\nuan_bg.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	//��������Ƶ�ڴ�dc���ݵ�dc
	m_dcBG.CreateCompatibleDC(&dc);
	//��λͼѡ����Դ�ڴ�
	m_dcBG.SelectObject(bmp);


	//��ʼ���ڴ�dc
	m_dcMem.CreateCompatibleDC(&dc);
	CBitmap bmpMem;
	bmpMem.CreateCompatibleBitmap(&dc,1600,1125);
	m_dcMem.SelectObject(bmpMem);

	//���Ʊ������ڴ�dc��
	m_dcMem.BitBlt(0, 0, 1600, 1125, &m_dcBG, 0, 0, SRCCOPY);


}

void CGameDlg::ChangeButton()
{

	m_bt_start.m_bDrawFocus = FALSE;
	m_bt_start.m_bTransparent = TRUE;
	m_bt_start.EnableWindowsTheming(FALSE);
	m_bt_start.SetFaceColor(RGB(112, 184, 66), true);

	m_bt_stop.m_bDrawFocus = FALSE;
	m_bt_stop.m_bTransparent = TRUE;
	m_bt_stop.EnableWindowsTheming(FALSE);
	m_bt_stop.SetFaceColor(RGB(112, 184, 66), true);

	m_bt_reset.m_bDrawFocus = FALSE;
	m_bt_reset.m_bTransparent = TRUE;
	m_bt_reset.EnableWindowsTheming(FALSE);
	m_bt_reset.SetFaceColor(RGB(112, 184, 66), true);

	m_bt_help.m_bDrawFocus = FALSE;
	m_bt_help.m_bTransparent = TRUE;
	m_bt_help.EnableWindowsTheming(FALSE);
	m_bt_help.SetFaceColor(RGB(112, 184, 66), true);
	
	m_bt_hint.m_bDrawFocus = FALSE;
	m_bt_hint.m_bTransparent = TRUE;
	m_bt_hint.EnableWindowsTheming(FALSE);
	m_bt_hint.SetFaceColor(RGB(112, 184, 66), true);

	m_bt_pro.m_bDrawFocus = FALSE;
	m_bt_pro.m_bTransparent = TRUE;
	m_bt_pro.EnableWindowsTheming(FALSE);
	m_bt_pro.SetFaceColor(RGB(112, 184, 66), true);
}

BOOL CGameDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	UpdateWindow();


	CRect rect;
	this->GetClientRect(&rect);     //ȡ�ͻ�����С  
	old.x = rect.right - rect.left;
	old.y = rect.bottom - rect.top;


	m_flag = control->GetFlag();
	InitBackground();
	InitElement();

	ModifyStyleEx(0, WS_EX_APPWINDOW);
	ShowWindow(SW_SHOW);
	ChangeButton();
	if (m_flag.bPro == true)
	{
		GetDlgItem(IDC_BUTTON_PRO)->ShowWindow(SW_SHOW);
	}
	else if (m_flag.bPro == false)
	{
		GetDlgItem(IDC_BUTTON_PRO)->ShowWindow(SW_HIDE);
	}
	if (m_flag.bScore == true)
	{
		GetDlgItem(IDC_BUTTON_HINT)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_RESET)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_PRO)->EnableWindow(FALSE);
	}
	else if (m_flag.bScore == false)
	{

	}
	if (m_flag.bTimer == true)
	{
		GetDlgItem(IDC_GAME_TIME)->ShowWindow(SW_SHOW);
	}
	else if (m_flag.bTimer == false)
	{
		GetDlgItem(IDC_GAME_TIME)->ShowWindow(SW_HIDE);
	}
	this->SetWindowTextW(m_flag.title);
	return TRUE;  // return TRUE unless you set the focus to a control
				  // �쳣: OCX ����ҳӦ���� FALSE
}

void CGameDlg::UpdateWindow()
{
	CRect rtWin;
	CRect rtClient;
	this->GetWindowRect(rtWin);//��ô��ڴ�С
	this->GetClientRect(rtClient);//��ÿͻ�����С

								  //����������߿�Ĵ�С
	int nSpanWidth = rtWin.Width() - rtClient.Width();
	int nSpanHeight = rtWin.Height() - rtClient.Height();

	//���ô��ڴ�С
	MoveWindow(0, 0, 1600 + nSpanWidth,  1000+ nSpanHeight);
	//���öԻ�����ʾ��������
	CenterWindow();
}


void CGameDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting
					   // TODO: �ڴ˴�������Ϣ�����������
					   // ��Ϊ��ͼ��Ϣ���� CDialogEx::OnPaint()
	dc.BitBlt(0, 0, 1600, 1125, &m_dcMem, 0, 0, SRCCOPY);//���Ʊ���ͼƬ
}
void CGameDlg::UpdateMap()
{
	//��ʼ������
	int nLeft = m_ptGameTop.x;
	int nTop = m_ptGameTop.y;
	//Ԫ�صĳ��Ϳ�
	int nElemW = m_sizeElem.cx;
	int nElemH = m_sizeElem.cy;
	m_dcMem.BitBlt(m_rtGameRect.left, m_rtGameRect.top, m_rtGameRect.Width(), m_rtGameRect.Height(),
		&m_dcBG, m_rtGameRect.left, m_rtGameRect.top, SRCCOPY);
	for (int i = 0; i < CGameControl::s_nRows; i++)
	{
		for (int j = 0; j < CGameControl::s_nCols; j++)
		{
			int nElemVal = control->GetElement(i, j);
			if (nElemVal == BLANK) continue;
			//m_dcMem.BitBlt(nLeft + j * nElemW, nTop + i * nElemH, nElemW, nElemH, &m_dcElement, 0, anMap[i][j] * nElemH, SRCCOPY);
			m_dcMem.BitBlt(nLeft + j * nElemW, nTop + i * nElemH, nElemW, nElemH, &m_dcMask, 0, nElemVal * nElemH, SRCPAINT);
			m_dcMem.BitBlt(nLeft + j * nElemW, nTop + i * nElemH, nElemW, nElemH, &m_dcElement, 0, nElemVal * nElemH, SRCAND);
		}
	}
	InvalidateRect(m_rtGameRect, FALSE);

}

void CGameDlg::OnClickedBtnStart()
{
	control->StartGame();

	m_bPlaying = true;
	this->GetDlgItem(IDC_BTN_START)->EnableWindow(FALSE);

	control->InitGrade();//���û���
	m_ProNum = 0;//���õ�����
	UpdateMap();
	if(m_flag.bScore==true)
		DrawGameGrade();
	if (m_flag.bPro==true)
		DrawProNum();
	if (m_flag.bTimer == true && m_flag.bScore == true)
		DrawLevel();
	InvalidateRect(m_rtGameRect, FALSE);
	//��ʼ��������
	m_GameProgress.SetRange(0, 60 * 5);//��ʼ��Χ
	m_GameProgress.SetStep(-1);//��ʼ����ֵ
	m_GameProgress.SetPos(60 * 5);//��ʼֵ
	//������ʱ��
	if (control->GetFlag().bTimer == true)
	{
		this->SetTimer(PLAY_TIMER_ID, 1000, NULL);
	}
}


void CGameDlg::OnLButtonUp(UINT nFlags, CPoint point)
{
	if (m_bPlaying == true)
	{
		if (point.x < m_ptGameTop.x || point.y < m_ptGameTop.y)
		{
			return CDialogEx::OnLButtonUp(nFlags, point);
		}
		CRect m_rtGameRect;//��Ϸ����

		// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ

		int nRow = (point.y - m_ptGameTop.y) / m_sizeElem.cy;//�����������Ԫ�ص��к�
		int nCol = (point.x - m_ptGameTop.x) / m_sizeElem.cx;//�к�
		if (nRow >= 10 || nCol >= 16)
			return CDialogEx::OnLButtonUp(nFlags, point);
		//CDialogEx::OnLButtonUp(nFlags, point);
		if (m_bFirstPoint == true)//Ԫ�ص�һ��ѡ��
		{
			DrawTipFrame(nRow, nCol);
			control->SetFirstPoint(nRow, nCol);
		}
		else
		{
			DrawTipFrame(nRow, nCol);
			control->SetSecPoint(nRow, nCol);
			
			int nVexNum = 0;
				//�ж�����ѡ����Ƿ�����ͬͼƬ
			
			if (control->Link(m_aPath, nVexNum))
			{
				control->setGrade(10);
				DrawTipLine(m_aPath,nVexNum);
				if (m_flag.bScore==true)
					DrawGameGrade();
				if (m_flag.bPro == true)
				{
					SetProNum(control->GetGrade() - 10);
					DrawProNum();
				}
				if (m_flag.bScore == true && m_flag.bTimer == true)
					DrawLevel();
				if (m_flag.bScore==true)
					CaculateGameGrade();
				UpdateMap();
				control->SetSecPoint(nRow, nCol);
			}
			
			Sleep(200);
			InvalidateRect(m_rtGameRect, FALSE);
			JudgeWin();
		}
		m_bFirstPoint = !m_bFirstPoint;
	}
}


// ��Ԫ�ر����ѡ��ʱ���ú�ɫ���ע
void CGameDlg::DrawTipFrame(int nRow, int nCol)
{
	CClientDC dc(this);
	CBrush brush(RGB(233, 43, 43));//��ˢ
	CRect rtTipFrame;
	//�����ɫ�������
	rtTipFrame.left = m_ptGameTop.x + nCol * m_sizeElem.cx;
	rtTipFrame.top = m_ptGameTop.y + nRow * m_sizeElem.cy;
	rtTipFrame.right = rtTipFrame.left + m_sizeElem.cx;
	rtTipFrame.bottom = rtTipFrame.top + m_sizeElem.cy;
	dc.FrameRect(rtTipFrame, &brush);
}





void CGameDlg::DrawTipLine(Vertex aPath[160],int VexNum)
{
	CClientDC dc(this);
	//���û���
	CPen penLine(PS_SOLID,2,RGB(183, 248, 130));
	//������ѡ��dc
	CPen* OldPen = dc.SelectObject(&penLine);
	//����������
	dc.MoveTo(m_ptGameTop.x + aPath[0].col*m_sizeElem.cx + m_sizeElem.cx / 2,
		m_ptGameTop.y + aPath[0].row*m_sizeElem.cy + m_sizeElem.cy / 2);
	for (int i = 1; i < VexNum; i++)
	{
		dc.LineTo(m_ptGameTop.x + aPath[i].col*m_sizeElem.cx + m_sizeElem.cx / 2,
		m_ptGameTop.y + aPath[i].row*m_sizeElem.cy + m_sizeElem.cy / 2);
	}
	dc.SelectObject(OldPen);
}


void CGameDlg::OnClickedButtonHint()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (control->Help(m_aPath, nVexNum) == true)
	{
		
		DrawTipFrame(m_aPath[0].row, m_aPath[0].col);
		DrawTipFrame(m_aPath[nVexNum-1].row, m_aPath[nVexNum-1].col);
		
		DrawTipLine(m_aPath,nVexNum);
		if (m_flag.bScore == true)
		{
			SetProNum(control->GetGrade() + 20);
			DrawGameGrade();
		}
		if (m_flag.bPro==true)
			DrawProNum();
		if (m_flag.bScore == true && m_flag.bTimer == true)
			DrawLevel();
		if (m_flag.bScore==true)
			CaculateGameGrade();
		
		//UpdateMap();
	//	Sleep(400);
		//InvalidateRect(m_rtGameRect, FALSE);
	}
}


void CGameDlg::OnClickedButtonReset()
{
	// �������ź���
	control->Reset();
	//���µ�ͼ
	if (m_flag.bScore==true)
		DrawGameGrade();
	if (m_flag.bPro == true)
	{
		SetProNum(control->GetGrade() + 50);
		DrawProNum();
	}
	if (m_flag.bScore == true && m_flag.bTimer == true)
		DrawLevel();
	if (m_flag.bScore==true)
		CaculateGameGrade();
	UpdateMap();
	InvalidateRect(m_rtGameRect, FALSE);
}


void CGameDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	if (nIDEvent == PLAY_TIMER_ID && m_bPlaying)
	{
		//��Ϸʱ���һ��
		m_GameProgress.StepIt();
	}

	DrawGameTime();
	if (m_GameProgress.GetPos() == 0)
	{
		KillTimer(nIDEvent);
		m_bPlaying = false;
		this->GetDlgItem(IDC_BTN_START)->EnableWindow(TRUE);
		if (m_flag.bTimer == true && m_flag.bScore == true)
		{
			control->setGrade(m_ProNum * 30);
			DrawGameGrade();
			InvalidateRect(m_rtGameRect, FALSE);
			int yon = MessageBox(_T("���ź���ʱ�䵽�ˣ�Ҫ�������Ļ�����Ϣ��"),NULL, MB_YESNO);
			if (yon == IDYES)//�Ǳ�ѡ,�������
			{
				control->SaveScore();
			}
		}
		else 
			MessageBox(_T("ʱ�䵽�ˣ������ˣ�"));
	}
	CDialogEx::OnTimer(nIDEvent);
}


// ������Ϸʱ��
void CGameDlg::DrawGameTime()
{
	CClientDC dc(this);
	dc.SetTextColor(RGB(100, 213, 8));
	dc.SetBkColor(RGB(254, 250, 176));
	CFont font;
	font.CreatePointFont(240, L"����",&dc);
	CFont *def_font = dc.SelectObject(&font);

	CString str;
	int time = m_GameProgress.GetPos();
	str.Format(_T("%d"), time);
	CString strs;
	switch (str.GetLength())
	{
	case 1:
		strs.Format(_T("00%d"), time);
		break;
	case 2:
		strs.Format(_T("0%d"), time);
		break;
	case 3:
		strs.Format(_T("%d"), time);
		break;
	default:
		break;
	}

	dc.TextOutW(1250, 105+80*10, strs,3);
	dc.SelectObject(&def_font);
}


// �ж�ʤ��
void CGameDlg::JudgeWin()
{
	int gameStatus = control->IsWin(m_GameProgress.GetPos());
	if (gameStatus == GAME_PLAY)
	{
		return;
	}
	else if (gameStatus == GAME_NEXT)//������һ�ؿ�
	{
		KillTimer(PLAY_TIMER_ID);
		//��ʾ��Ϣ
		//CString grade;
		//grade.Format(control->GetGrade());
		CString strTitle;
		this->GetWindowTextW(strTitle);
		int yon=MessageBox(_T("��ϲͨ�أ��Ƿ�ǰ����һ�أ�"), strTitle, MB_YESNO);
		if (yon == IDYES)//ǰ����һ��
		{
				
			control->StartGame();

			m_bPlaying = true;
			this->GetDlgItem(IDC_BTN_START)->EnableWindow(FALSE);

			UpdateMap();
			if (m_flag.bScore == true)
				DrawGameGrade();
			if (m_flag.bPro == true)
				DrawProNum();
			if (m_flag.bScore == true && m_flag.bTimer == true)
				DrawLevel();
			InvalidateRect(m_rtGameRect, FALSE);
			//��ʼ��������
			m_GameProgress.SetRange(0, 60 * 5);//��ʼ��Χ
			m_GameProgress.SetStep(-1);//��ʼ����ֵ
			m_GameProgress.SetPos(60 * 5);//��ʼֵ
										  //������ʱ��
			if (control->GetFlag().bTimer == true)
			{
				this->SetTimer(PLAY_TIMER_ID, 1000, NULL);
			}
		}
		else//��������һ�ؿ�
		{
			control->setGrade(m_ProNum * 30);
			DrawGameGrade();
			InvalidateRect(m_rtGameRect, FALSE);
			int yon = MessageBox(_T("��Ϸ������Ҫ�������Ļ�����Ϣ��"), strTitle, MB_YESNO);
			if (yon == IDYES)//�Ǳ�ѡ,�������
			{
				control->SaveScore();
			}
		}
	}
	else
	{
		m_bPlaying = false;
		KillTimer(PLAY_TIMER_ID);
		//��ʾ��Ϣ
		//CString grade;
		//grade.Format(control->GetGrade());
		CString strTitle;
		this->GetWindowTextW(strTitle);
		if (gameStatus == GAME_SUCCESS)
		{
			if (m_flag.bScore == false)
			{
				MessageBox(_T("��ʤ����"), strTitle);
			}
			else if (m_flag.bScore == true)//�л��ֹ���
			{
				control->setGrade(m_ProNum * 30);
				DrawGameGrade();
				InvalidateRect(m_rtGameRect, FALSE);
				int yon = MessageBox(_T("��ʤ����Ҫ�������Ļ�����Ϣ��"), strTitle, MB_YESNO);
				if (yon == IDYES)//�Ǳ�ѡ,�������
				{
					control->SaveScore();
				}
			}
		}
		
		else if (gameStatus == GAME_LOSE)
		{
			if (m_flag.bScore==false)
				MessageBox(_T("���ź���ʱ�䵽��!"), strTitle);
			else if (m_flag.bTimer == true && m_flag.bScore == true)
			{
				control->setGrade(m_ProNum * 30);
				DrawGameGrade();
				InvalidateRect(m_rtGameRect, FALSE);
				int yon = MessageBox(_T("���ź���ʱ�䵽�ˣ�Ҫ�������Ļ�����Ϣ��"), strTitle, MB_YESNO);
				if (yon == IDYES)//�Ǳ�ѡ,�������
				{
					control->SaveScore();
				}
			}
		}
		
		//��ԭ��ʼ��Ϸ��ť
		UpdateMap();
		this->GetDlgItem(IDC_BTN_START)->EnableWindow(TRUE);
	}
}


void CGameDlg::OnBnClickedButtonStop()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_bPlaying = !m_bPlaying;
	if (m_bPlaying)
	{
		GetDlgItem(IDC_BUTTON_STOP)->SetWindowTextW(_T("��ͣ��Ϸ"));

		this->GetDlgItem(IDC_BUTTON_RESET)->EnableWindow(TRUE);
		this->GetDlgItem(IDC_BUTTON_HINT)->EnableWindow(TRUE);
		UpdateMap();
		InvalidateRect(m_rtGameRect, FALSE);
	}
	else
	{
		GetDlgItem(IDC_BUTTON_STOP)->SetWindowTextW(_T("������Ϸ"));

		this->GetDlgItem(IDC_BUTTON_RESET)->EnableWindow(FALSE);
		this->GetDlgItem(IDC_BUTTON_HINT)->EnableWindow(FALSE);
		this->GetDlgItem(IDC_BUTTON_PRO)->EnableWindow(FALSE);
		m_dcMem.BitBlt(m_rtGameRect.left, m_rtGameRect.top, 1280, 900,
			&m_dcCache, m_rtGameRect.left, m_rtGameRect.top, SRCCOPY);
		InvalidateRect(m_rtGameRect, FALSE);
	}
}


void CGameDlg::OnBnClickedButtonHelp()
{
	CHelpDlg dlg;
	if (m_flag.bScore == true&&m_flag.bTimer==false)
		dlg.setnMode(1);
	else if (m_flag.bTimer == true&&m_flag.bScore==false)
		dlg.setnMode(0);
	else if (m_flag.bScore == true && m_flag.bTimer == true)
		dlg.setnMode(3);
	else
		dlg.setnMode(2);
	dlg.DoModal();
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}
void CGameDlg::SetGameModel(CGameControl* pGameC)
{
	control = pGameC;
}


// ���ƻ���
void CGameDlg::DrawGameGrade()
{
	CClientDC dc(this);
	dc.SetTextColor(RGB(100, 213, 8));
	dc.SetBkColor(RGB(254, 250, 176));
	CFont font;
	font.CreatePointFont(180, L"����", &dc);
	CFont *def_font = dc.SelectObject(&font);

	CString str;
	int grade = control->GetGrade();
	str.Format(_T("%d"),grade);
	CString strs;
	switch (str.GetLength())
	{
	case 1:
		strs.Format(_T("000%d"), grade);
		break;
	case 2:
		strs.Format(_T("00%d"), grade);
		break;
	case 3:
		strs.Format(_T("0%d"), grade);
		break;
	case 4:
		strs.Format(_T("%d"), grade);
		break;
	default:
		break;
	}
	strs = _T("����:") + strs;
	dc.TextOutW(1400, 50 + 80 * 8, strs);
	dc.SelectObject(&def_font);
}


// ������Ϸ�������ð�ť״̬
void CGameDlg::CaculateGameGrade()
{
	int grade = control->GetGrade();
	if (grade >= 20)
	{
		GetDlgItem(IDC_BUTTON_HINT)->EnableWindow(TRUE);
	}
	else if (grade < 20)
	{
		GetDlgItem(IDC_BUTTON_HINT)->EnableWindow(FALSE);
	}
	if (grade >= 50)
	{
		GetDlgItem(IDC_BUTTON_RESET)->EnableWindow(TRUE);
	}
	else if (grade < 50)
	{
		GetDlgItem(IDC_BUTTON_RESET)->EnableWindow(FALSE);
	}
	if (m_ProNum <= 0)
	{
		GetDlgItem(IDC_BUTTON_PRO)->EnableWindow(FALSE);
	}
	else if (m_ProNum > 0)
	{
		GetDlgItem(IDC_BUTTON_PRO)->EnableWindow(TRUE);
	}
}


void CGameDlg::OnBnClickedButtonPro()
{
	m_bPro = true;
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (control->ProLink() == true)
	{
		m_ProNum--;
		control->setGrade(10);
		SetProNum(control->GetGrade() - 10);
		DrawGameGrade();
		if (m_flag.bPro==true)
			DrawProNum();
		if (m_flag.bScore == true && m_flag.bTimer == true)
			DrawLevel();
		if (m_flag.bScore==true)
			CaculateGameGrade();
		UpdateMap();
	}
	Sleep(200);
	InvalidateRect(m_rtGameRect, FALSE);
	JudgeWin();
}


// ���õ�����
void CGameDlg::SetProNum(int grade)
{
	int newgrade = control->GetGrade();
	if ((newgrade / 100) > (grade / 100))
		m_ProNum++;
}


// ���Ƶ�����
void CGameDlg::DrawProNum()
{
	CClientDC dc(this);
	dc.SetTextColor(RGB(100, 213, 8));
	dc.SetBkColor(RGB(254, 250, 176));
	CFont font;
	font.CreatePointFont(180, L"����", &dc);
	CFont *def_font = dc.SelectObject(&font);

	CString str;
	str.Format(_T("%d"), m_ProNum);
	CString strs;
	switch (str.GetLength())
	{
	case 1:
		strs.Format(_T("00%d"), m_ProNum);
		break;
	case 2:
		strs.Format(_T("0%d"), m_ProNum);
		break;
	case 3:
		strs.Format(_T("%d"), m_ProNum);
		break;
	default:
		break;
	}
	strs = _T("������:") + strs;
	dc.TextOutW(1390, 50 + 80 * 7, strs);
	dc.SelectObject(&def_font);
}


// ��ʾ�ؿ���
void CGameDlg::DrawLevel()
{
	int level = control->GetLevel();
	CClientDC dc(this);
	dc.SetTextColor(RGB(100, 213, 8));
	dc.SetBkColor(RGB(254, 250, 176));
	CFont font;
	font.CreatePointFont(180, L"����", &dc);
	CFont *def_font = dc.SelectObject(&font);

	CString str;
	str.Format(_T("%d"), level);
	CString strs;
	switch (str.GetLength())
	{
	case 1:
		strs.Format(_T("0%d"), level);
		break;
	case 2:
		strs.Format(_T("%d"), level);
		break;
	default:
		break;
	}
	strs = _T("�ؿ���:") + strs;
	dc.TextOutW(1390, 50 + 80 * 9, strs);
	dc.SelectObject(&def_font);
}



void CGameDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);
	// TODO: Add your message handler code here
	if (nType == SIZE_RESTORED || nType == SIZE_MAXIMIZED)
	{
		ReSize();
	}
}


void CGameDlg::ReSize()
{
	float fsp[2];
	POINT Newp; //��ȡ���ڶԻ���Ĵ�С
	CRect recta;
	GetClientRect(&recta);     //ȡ�ͻ�����С  
	Newp.x = recta.right - recta.left;
	Newp.y = recta.bottom - recta.top;
	fsp[0] = (float)Newp.x / old.x;
	fsp[1] = (float)Newp.y / old.y;
	CRect Rect;
	int woc;
	CPoint OldTLPoint, TLPoint; //���Ͻ�
	CPoint OldBRPoint, BRPoint; //���½�
	HWND  hwndChild = ::GetWindow(m_hWnd, GW_CHILD);  //�г����пؼ�  
	while (hwndChild)
	{
		woc = ::GetDlgCtrlID(hwndChild);//ȡ��ID
		GetDlgItem(woc)->GetWindowRect(Rect);
		ScreenToClient(Rect);
		OldTLPoint = Rect.TopLeft();
		TLPoint.x = long(OldTLPoint.x*fsp[0]);
		TLPoint.y = long(OldTLPoint.y*fsp[1]);
		OldBRPoint = Rect.BottomRight();
		BRPoint.x = long(OldBRPoint.x *fsp[0]);
		BRPoint.y = long(OldBRPoint.y *fsp[1]);
		Rect.SetRect(TLPoint, BRPoint);
		GetDlgItem(woc)->MoveWindow(Rect, TRUE);
		hwndChild = ::GetWindow(hwndChild, GW_HWNDNEXT);
	}
	old = Newp;
}


