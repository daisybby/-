// SettingDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "LLK.h"
#include "SettingDlg.h"
#include "afxdialogex.h"
#include "ThemeOptionDlg.h"
#include "CConfig.h"
// CSettingDlg �Ի���

IMPLEMENT_DYNAMIC(CSettingDlg, CDialogEx)

CSettingDlg::CSettingDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG_SETTING, pParent)
{

}

CSettingDlg::~CSettingDlg()
{
}

void CSettingDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TAB_SETTING, m_tabSetting);
}


BEGIN_MESSAGE_MAP(CSettingDlg, CDialogEx)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB_SETTING, &CSettingDlg::OnTcnSelchangeTabSetting)
	ON_BN_CLICKED(IDOK, &CSettingDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CSettingDlg::OnBnClickedCancel)
END_MESSAGE_MAP()


// CSettingDlg ��Ϣ��������


void CSettingDlg::OnTcnSelchangeTabSetting(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	*pResult = 0;
	int nNewSel = m_tabSetting.GetCurSel();
	if (nNewSel != 0)
		m_dlgTheme.ShowWindow(SW_HIDE);
	else if (nNewSel == 0)
		m_dlgTheme.ShowWindow(SW_SHOW);
	/*if (nNewSel!=m_nCurTab)
	{
		m_pDlg[m_nCurTab]->ShowWindow(SW_HIDE);
		m_pDlg[nNewSel]->ShowWindow(SW_SHOW);
		m_nCurTab = nNewSel;
	}*/
}


void CSettingDlg::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CThemeOptionDlg dlg;
	m_dlgTheme.Save();
	CDialogEx::OnOK();
}


void CSettingDlg::OnBnClickedCancel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CThemeOptionDlg dlg;
	CDialogEx::OnCancel();
}


BOOL CSettingDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��

	m_tabSetting.InsertItem(0, _T("��������"));
	m_tabSetting.InsertItem(1, _T("��Ч����"));
	m_dlgTheme.Create(IDD_CONFIG_THEME,&m_tabSetting);
	m_pDlg[0] = &m_dlgTheme;
	CRect rc;
	m_tabSetting.GetClientRect(&rc);
	rc.top += 23;
	rc.left += 3;
	rc.bottom -= 2;
	rc.right -= 2;
	m_dlgTheme.MoveWindow(&rc);
	m_dlgTheme.ShowWindow(SW_SHOW);
	m_tabSetting.SetCurSel(0);
	m_dlgTheme.SetStatus(false);
	return TRUE;  // return TRUE unless you set the focus to a control
				  // �쳣: OCX ����ҳӦ���� FALSE
}

