#include "stdafx.h"
#include "CEasyGame.h"
#include <Windows.h>
#include "CScoreLogic.h"
CEasyGame::CEasyGame()
{
}


CEasyGame::~CEasyGame()
{
}

void CEasyGame::StartGame()
{
	CGameLogic logic;
	logic.InitMap(m_Graph);
}

int CEasyGame::IsWin()
{
	CGameLogic logic;
	if (logic.IsBlank(m_Graph) == true)
	{
		m_Graph.ClearGraph();
		return GAME_SUCCESS;
	}
	return GAME_PLAY;
}

bool CEasyGame::Help(Vertex anPath[4], int& nVertexNum)
{
	CGameLogic logic;
	if (logic.IsBlank(m_Graph) == true)
	{
		nVertexNum = 0;
		return false;
	}
	if (logic.SearchValidPath(m_Graph))
	{
		m_nGrade -= 20;
		nVertexNum = logic.GetVexPath(m_Graph,anPath);
		return true;
	}
	return false;
}

void CEasyGame::Reset()
{
	CGameLogic logic;
	m_nGrade -= 50;
	logic.ResetGraph( m_Graph);
}




// ʹ�õ�������
bool CEasyGame::ProLink()
{
	if (m_ptSelFirst.row == m_ptSelSec.row&&m_ptSelFirst.col == m_ptSelSec.col)//ѡ�е�ͬһ��ͼƬ
	{
		return false;
	}
	if (m_ptSelFirst.info == m_ptSelSec.info&&m_ptSelFirst.info != BLANK && m_ptSelSec.info != BLANK)
	{
		CGameLogic logic;
		logic.Clear(m_Graph, m_ptSelFirst, m_ptSelSec, m_Graph);
		return true;
	}
	return false;
}


// �������
bool CEasyGame::SaveScore()
{
	//��ȡ��ǰʱ��
	SYSTEMTIME sys;
	GetLocalTime(&sys);
	CString time, year, month, day, hour, minute, second;
	year.Format(_T("%d"), sys.wYear);
	month.Format(_T("%d"), sys.wMonth);
	if (month.GetLength() == 1)
	{
		
		month = _T("0") + month;
	}
	day.Format(_T("%d"), sys.wDay);
	if (day.GetLength() == 1)
	{

		day = _T("0") + day;
	}
	hour.Format(_T("%d"), sys.wHour);
	if (hour.GetLength() == 1)
	{

		hour = _T("0") + hour;
	}
	minute.Format(_T("%d"), sys.wMinute);
	if (minute.GetLength() == 1)
	{

		minute = _T("0") + minute;
	}
	second.Format(_T("%d"), sys.wSecond);
	if (second.GetLength() == 1)
	{

		second = _T("0") + second;
	}
	time = year + month + day + hour + minute + second;
	Score ascore;
	ascore.strName = time;
	ascore.nGrade = GetGrade();
	ascore.nMode = 1;
	CScoreLogic logic;
	logic.SaveScore(ascore);
	return false;
}


