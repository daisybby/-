#pragma once

// CThemeOptionDlg �Ի���

class CThemeOptionDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CThemeOptionDlg)

public:
	CThemeOptionDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CThemeOptionDlg();

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CONFIG_THEME };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	int m_nThemeType;
	afx_msg void OnBnClickedRadioAinimal();
	afx_msg void OnBnClickedRadioShicai();
	afx_msg void OnBnClickedRadioFoot();
	afx_msg void OnBnClickedRadioSelf();
	CString m_strElemPath;
	CString m_strMaskPath;
	afx_msg void OnBnClickedButtonElementfile();
	afx_msg void OnBnClickedButtonMaskfile();
	void Save();
	virtual BOOL OnInitDialog();
	void SetStatus(bool status);//�����ı����Ƿ�ɱ༭
	afx_msg void OnEnChangeEditElem();
	afx_msg void OnEnChangeEditMask();
};
