#pragma once
#include "global.h"
class CScoreDao
{
public:
	CScoreDao();
	~CScoreDao();
	bool Save(const CString& strPath, Score& score);
	// ��ȡ���а���Ϣ
	int Read(const CString& strPath, RankArray& ranks, int nMode);
};

