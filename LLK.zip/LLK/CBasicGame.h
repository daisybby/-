#pragma once
#include "CGameControl.h"
class CBasicGame :
	public CGameControl
{
private:
public:
	CBasicGame();
	~CBasicGame();
	void StartGame();
};

