#include "stdafx.h"
#include "CBasicGame.h"


CBasicGame::CBasicGame()
{
}


CBasicGame::~CBasicGame()
{
}

void CBasicGame::StartGame()
{
	CGameLogic logic;
	logic.InitMap(m_Graph);
}
