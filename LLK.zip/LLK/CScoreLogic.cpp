#include "stdafx.h"
#include "CScoreLogic.h"
#include "global.h"
#include "CScoreDao.h"
CScoreLogic::CScoreLogic()
{
}


CScoreLogic::~CScoreLogic()
{
}


// ������ֲ�������ֵȼ�
bool CScoreLogic::SaveScore(Score& score)
{
	if (score.nGrade < 500)
		score.nLevel = 1;
	else if (score.nGrade >= 500 && score.nGrade < 1000)
		score.nLevel = 2;
	else if (score.nGrade >= 1000)
		score.nLevel = 3;
	CScoreDao dao;
	CString path;
	path.Format(_T("C:\\Users\\Ԭӱӱ\\source\\repos\\LianLianKan\\LLK\\Score\\Score.llk"));
	dao.Save(path, score);
	return false;
}


int CScoreLogic::SearchRank(RankArray& ranks, int nMode)
{
	CScoreDao dao;
	CString path;
	path.Format(_T("C:\\Users\\Ԭӱӱ\\source\\repos\\LianLianKan\\LLK\\Score\\Score.llk"));
	int count,index;//����
	count=dao.Read(path, ranks, nMode);
	//���ݻ��ֽ�������
	for (int i = 0; i < count; i++)
	{
		int max = ranks[i].nGrade;
		for (int j = i; j < count; j++)
		{
			if (ranks[j].nGrade >= max)
			{
				max = ranks[j].nGrade;
				index = j;
			}
		}
		Score temp = ranks[index];
		ranks[index] = ranks[i];
		ranks[i] = temp;
	}
	return count;
}
