#pragma once
#include "afxwin.h"


// CHelpDlg �Ի���

class CHelpDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CHelpDlg)

public:
	CHelpDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CHelpDlg();

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_HELP };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	virtual BOOL OnInitDialog();
protected:
	CDC m_dcHelp;
	CDC m_dcMem;

	CRect m_rtHelp;
	CScrollBar m_horiScrollbar;
	int nMin = 0;
	int nMax;
public:
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	void UpdateHelp(int nPos);
	// ��Ϸģʽ
	void setnMode(int mode);
	int m_nMode;
};
